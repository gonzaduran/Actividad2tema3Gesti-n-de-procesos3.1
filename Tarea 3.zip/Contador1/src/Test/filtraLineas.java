package Test;

import java.util.Scanner;
import java.io.*;

/**
 * Programa filtraLineas
 * Lee de la entrada estándar y muestra solo las líneas con más de 20 caracteres.
 * @author TuNombre
 */
public class filtraLineas {
    public static void main(String[] args) {
    	try (BufferedReader br = new BufferedReader (new InputStreamReader(System.in)))
    	{
    		String linea;
    		while((linea = br.readLine())!=null)
    		{
    			if(linea.length() > 20)
    			{
    				System.out.println(linea);
    			}
    		}
    	
    			}catch(IOException e)
    			{
    				System.out.println("Eror al leer las lineas");
    			}
    }
}
