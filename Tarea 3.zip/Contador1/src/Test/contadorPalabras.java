package Test;

import java.util.Scanner;
import java.io.*;

/**
 * Programa contadorPalabras
 * Cuenta el número total de palabras recibidas desde la entrada estándar.
 * Una palabra es cualquier secuencia separada por espacios.
 * @author TuNombre
 */
public class contadorPalabras {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int total = 0;

        while (sc.hasNextLine()) {
            String linea = sc.nextLine().trim();
            if (!linea.isEmpty()) {
                total += linea.split("\\s+").length;
            }
        }

        sc.close();
        System.out.println("Número total de palabras: " + total);
    }
}
