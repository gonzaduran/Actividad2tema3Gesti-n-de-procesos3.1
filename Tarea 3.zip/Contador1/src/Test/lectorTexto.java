package Test;

import java.io.*;

/**
 * Programa lectorTexto
 * Lee un archivo (entrada.txt) y lo muestra línea a línea por consola.
 * Si no existe, muestra un mensaje de error.
 * @author TuNombre
 */
public class lectorTexto {
    public static void main(String[] args) {
        File archivo = new File("C:\\Users\\Usuario1\\Desktop\\PROGRAMACIÓN PROCESOS\\Contador1\\src\\Test\\archivo.txt");

        if (!archivo.exists()) {
            System.err.println("Error: El archivo entrada.txt no existe.");
            return;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
