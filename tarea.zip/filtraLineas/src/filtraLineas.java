import java.util.Scanner;

/**
 * Programa filtraLineas
 * Lee de la entrada estándar y muestra solo las líneas con más de 20 caracteres.
 * @author TuNombre
 */
public class filtraLineas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNextLine()) {
            String linea = sc.nextLine();
            if (linea.length() > 20) {
                System.out.println(linea);
            }
        }
        sc.close();
    }
}
